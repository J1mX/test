var Jsver = GetJScriptEngineInfo();
WScript.Echo(Jsver);
function GetJScriptEngineInfo(){
var Ver = "You are using " + ScriptEngine() + " Version ";
Ver += ScriptEngineMajorVersion() + ".";
Ver += ScriptEngineMinorVersion();
return Ver;
}